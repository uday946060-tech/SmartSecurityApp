const functions = require('firebase-functions');
const admin = require('firebase-admin');
const sgMail = require('@sendgrid/mail');
const axios = require('axios');
admin.initializeApp();
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

exports.handleIncident = functions.https.onRequest(async (req, res) => {
  try {
    const { event, photos, lat, lng, deviceId } = req.body;
    const targetEmail = process.env.TARGET_EMAIL;
    const mapsLink = (lat && lng) ? `https://maps.google.com/?q=${lat},${lng}` : 'Location not available';
    const html = `<p>Event: ${event}</p><p>Device: ${deviceId}</p><p>Location: <a href="${mapsLink}">${mapsLink}</a></p>`;

    const attachments = [];
    if (photos && photos.length) {
      for (let i=0;i<photos.length;i++){
        const url = photos[i];
        const resp = await axios.get(url, {responseType: 'arraybuffer'});
        attachments.push({content: Buffer.from(resp.data, 'binary').toString('base64'), filename: `photo_${i+1}.jpg`, type: 'image/jpeg', disposition: 'attachment'});
      }
    }

    const msg = { to: targetEmail, from: 'no-reply@yourdomain.com', subject: `Security Alert: ${event}`, html, attachments };
    await sgMail.send(msg);
    res.status(200).send({ok:true});
  } catch (e) {
    console.error(e);
    res.status(500).send({error: e.toString()});
  }
});
