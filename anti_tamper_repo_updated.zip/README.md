# AntiTamper Prototype Repo (Android + Wear OS + Firebase) — UPDATED

This updated ZIP adds a Distance Setting screen (manual input) stored locally in SharedPreferences.

## New files
- DistanceSettingActivity.kt : UI to input and save distance (meters)
- WatchMonitor.kt : reads/writes threshold from SharedPreferences and helper isBeyondThreshold()

## Quick setup
1. Unzip and open android-app in Android Studio.
2. Place google-services.json under android-app/app/
3. Add required dependencies (CameraX, Firebase storage, Play services location).
4. Build & run on a real device.
5. Open app, grant permissions, activate Device Admin.
6. Open Distance Settings (app menu) and set desired meter threshold.
7. Pair/watch logic: ensure Wear companion sends measuredDistanceMeters to phone; phone will call WatchMonitor.isBeyondThreshold() to decide alert.

Notes:
- Threshold is stored locally (SharedPreferences) as requested.
- You can change default threshold in WatchMonitor.kt (DEFAULT_DISTANCE constant).
