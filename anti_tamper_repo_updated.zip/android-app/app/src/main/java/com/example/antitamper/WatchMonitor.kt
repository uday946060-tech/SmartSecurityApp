package com.example.antitamper

import android.content.Context
import android.content.SharedPreferences
import android.util.Log

object WatchMonitor {
    private const val PREFS = "anti_tamper_prefs"
    private const val KEY_DISTANCE = "watch_distance_meters"

    // default threshold (meters)
    private const val DEFAULT_DISTANCE = 10

    fun getThreshold(context: Context): Int {
        val prefs: SharedPreferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getInt(KEY_DISTANCE, DEFAULT_DISTANCE)
    }

    fun isBeyondThreshold(context: Context, measuredDistanceMeters: Int): Boolean {
        val threshold = getThreshold(context)
        Log.d("WatchMonitor", "measured=$measuredDistanceMeters threshold=$threshold")
        return measuredDistanceMeters >= threshold
    }

    fun saveThreshold(context: Context, meters: Int) {
        val prefs: SharedPreferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putInt(KEY_DISTANCE, meters).apply()
    }
}
