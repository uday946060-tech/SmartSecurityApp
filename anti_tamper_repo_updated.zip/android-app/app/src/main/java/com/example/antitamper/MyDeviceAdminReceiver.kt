package com.example.antitamper

import android.app.admin.DeviceAdminReceiver
import android.content.Intent
import androidx.core.content.ContextCompat

class MyDeviceAdminReceiver : DeviceAdminReceiver() {
    override fun onPasswordFailed(context: android.content.Context, intent: Intent) {
        super.onPasswordFailed(context, intent)
        val svc = Intent(context, IncidentService::class.java).apply { putExtra("event","password_failed") }
        ContextCompat.startForegroundService(context, svc)
    }
}
