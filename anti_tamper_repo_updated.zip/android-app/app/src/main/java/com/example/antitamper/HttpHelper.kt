package com.example.antitamper

import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody

object HttpHelper {
    private val client = OkHttpClient()
    fun postJson(url: String, json: String) {
        val body = RequestBody.create("application/json; charset=utf-8".toMediaTypeOrNull(), json)
        val req = Request.Builder().url(url).post(body).build()
        client.newCall(req).execute().use { resp -> /* optional logging */ }
    }
}
