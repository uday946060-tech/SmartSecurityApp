package com.example.antitamper

import android.content.Context
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.CameraSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import java.io.File
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object CameraHelper {
    suspend fun captureSingle(context: Context, lensFacing: Int): File {
        val cameraProvider = ProcessCameraProvider.getInstance(context).get()
        val imageCapture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
        val selector = if (lensFacing == CameraSelector.LENS_FACING_FRONT) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        val outFile = File(context.cacheDir, "capture_${System.currentTimeMillis()}.jpg")
        val options = ImageCapture.OutputFileOptions.Builder(outFile).build()

        return suspendCancellableCoroutine { cont ->
            try {
                cameraProvider.unbindAll()
                // Binding without a lifecycleOwner may fail on some devices; consider launching a transparent Activity.
                cameraProvider.bindToLifecycle(/* lifecycleOwner */, selector, imageCapture)
            } catch (e: Exception) {
                // fallback - attempt to continue to take picture may fail
            }
            imageCapture.takePicture(options, ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageSavedCallback {
                override fun onError(exc: ImageCaptureException) { cont.resumeWithException(exc) }
                override fun onImageSaved(output: ImageCapture.OutputFileResults) { cont.resume(outFile) }
            })
        }
    }

    suspend fun captureFrontImage(context: Context) = captureSingle(context, CameraSelector.LENS_FACING_FRONT)
    suspend fun captureBackImage(context: Context) = captureSingle(context, CameraSelector.LENS_FACING_BACK)
}
