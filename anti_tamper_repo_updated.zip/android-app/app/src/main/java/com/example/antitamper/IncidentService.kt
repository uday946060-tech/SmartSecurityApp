package com.example.antitamper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import kotlinx.coroutines.*
import android.util.Log

class IncidentService : Service() {
    private val TAG = "IncidentService"
    private val CHANNEL_ID = "anti_tamper_channel"

    override fun onCreate() { super.onCreate(); createNotifChannel() }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val event = intent?.getStringExtra("event") ?: "unknown"
        startForeground(101, buildNotification("Processing security event..."))

        GlobalScope.launch(Dispatchers.IO) {
            try {
                // capture images (may require Activity lifecycle on some devices)
                val front = CameraHelper.captureFrontImage(applicationContext)
                delay(600)
                val back = CameraHelper.captureBackImage(applicationContext)
                val loc = LocationHelper.getLastLocation(applicationContext)
                val urls = FirebaseUploader.uploadFiles(listOf(front, back))
                notifyBackend(event, urls, loc)
            } catch (e: Exception) {
                Log.e(TAG, "Error in IncidentService", e)
            } finally {
                stopForeground(true)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun notifyBackend(event: String, urls: List<String>, loc: Pair<Double,Double>?) {
        val funcUrl = BuildConfig.FUNC_URL
        val deviceId = android.provider.Settings.Secure.getString(contentResolver, android.provider.Settings.Secure.ANDROID_ID)
        val photosJson = urls.toString()
        val latVal = loc?.first?.toString() ?: "null"
        val lngVal = loc?.second?.toString() ?: "null"
        val json = "{ "event":"" + event + "", "photos": " + photosJson + ", "lat": " + latVal + ", "lng": " + lngVal + ", "deviceId": "" + deviceId + "" }"
        HttpHelper.postJson(funcUrl, json)
    }

    private fun buildNotification(text: String): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        builder.setContentTitle("Security Monitor").setContentText(text).setSmallIcon(android.R.drawable.ic_dialog_alert).setOngoing(true)
        return builder.build()
    }

    private fun createNotifChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(CHANNEL_ID, "AntiTamper", NotificationManager.IMPORTANCE_HIGH)
            nm.createNotificationChannel(ch)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
