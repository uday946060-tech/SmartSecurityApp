package com.example.antitamper

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class DistanceSettingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // simple vertical layout programmatically to avoid xml step
        val root = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(50,50,50,50)
        }

        val edit = EditText(this).apply {
            hint = "Enter distance in meters (e.g. 10)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        val btnSave = Button(this).apply { text = "Save Distance" }

        root.addView(edit)
        root.addView(btnSave)

        setContentView(root)

        // show existing value
        val current = WatchMonitor.getThreshold(this)
        edit.setText(current.toString())

        btnSave.setOnClickListener {
            val txt = edit.text.toString().trim()
            if (txt.isEmpty()) {
                Toast.makeText(this, "Please enter a distance", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val meters = try { txt.toInt() } catch (e: Exception) { -1 }
            if (meters <= 0) {
                Toast.makeText(this, "Enter a valid positive number", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            WatchMonitor.saveThreshold(this, meters)
            Toast.makeText(this, "Saved: $meters meters", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
