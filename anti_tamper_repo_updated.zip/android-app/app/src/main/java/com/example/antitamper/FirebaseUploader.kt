package com.example.antitamper

import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.tasks.await
import java.io.File
import android.net.Uri

object FirebaseUploader {
    private val storage = FirebaseStorage.getInstance().reference

    suspend fun uploadFiles(files: List<File>): List<String> {
        val urls = mutableListOf<String>()
        for (f in files) {
            val path = "incidents/${System.currentTimeMillis()}_${f.name}"
            val ref = storage.child(path)
            ref.putFile(Uri.fromFile(f)).await()
            val url = ref.downloadUrl.await().toString()
            urls.add(url)
        }
        return urls
    }
}
