package com.example.antitamper

import android.content.Context
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object LocationHelper {
    suspend fun getLastLocation(context: Context): Pair<Double, Double>? {
        val client = LocationServices.getFusedLocationProviderClient(context)
        return suspendCancellableCoroutine { cont ->
            try {
                client.lastLocation.addOnSuccessListener { location ->
                    if (location != null) cont.resume(Pair(location.latitude, location.longitude)) else cont.resume(null)
                }.addOnFailureListener { e -> cont.resumeWithException(e) }
            } catch (e: Exception) { cont.resumeWithException(e) }
        }
    }
}
